document.getElementById('homeLink').addEventListener('click', function() {
    showSection('homeSection');
});

document.getElementById('loginLink').addEventListener('click', function() {
    showSection('loginSection');
});

document.getElementById('appointmentLink').addEventListener('click', function() {
    showSection('appointmentSection');
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'admin' && password === 'password123') {
        alert('Login successful!');
        showSection('appointmentSection');
    } else {
        alert('Invalid username or password.');
    }
});

document.getElementById('appointmentForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;

    const appointment = document.createElement('li');
    appointment.textContent = `${name} - ${date} at ${time}`;
    document.getElementById('appointments').appendChild(appointment);

    alert('Appointment booked successfully!');
});

function showSection(sectionId) {
    document.getElementById('homeSection').style.display = 'none';
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('appointmentSection').style.display = 'none';
    document.getElementById(sectionId).style.display = 'block';
}
